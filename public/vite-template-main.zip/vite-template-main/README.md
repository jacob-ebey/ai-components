# Vite + React + shadcn-ui

Used as the base for the preview on an AI project I'm working on in my spare time.
